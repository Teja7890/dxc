package org.animals;

public class Elephant {
		String colour = "BLUE";
		int Weight = 1880;
		int age = 35;
		public void vegetarian()
		{
	System.out.println(" ELEPHANT IA LOVER FOR VEGETARIAN");
		}
		public void canClimb() {
			System.out.println("CLIMBING IS NOT A HABIT OF ELEPHANT");
		}
		public void getSound()
		{
			System.out.println("ELEPHANT CAN SOUND LOUDLY");
		}
		public void displayLElephant(){
			System.out.println("Color is"+colour);
			System.out.println("Weight is"+Weight);
			System.out.println("age is"+age);
		}

	}



