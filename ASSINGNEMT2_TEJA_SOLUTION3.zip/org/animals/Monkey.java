package org.animals;

public class Monkey {
		String colour = "Black";
		int Weight = 18;
		int age = 14;
		public void vegetarian()
		{
	System.out.println(" MONKEY WILL EAT VEGETARIAN");
		}
		public void canClimb() {
			System.out.println("CLIMBING IS A HABIT OF MONKEY");
		}
		public void getSound()
		{
			System.out.println("MONKEY CAN NOT SOUND LOUDLY");
		}
		public void displayMonkey(){
			System.out.println("Color is"+colour);
			System.out.println("Weight is"+Weight);
			System.out.println("age is"+age);
		}

	}



