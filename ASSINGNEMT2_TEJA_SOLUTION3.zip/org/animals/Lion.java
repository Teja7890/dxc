package org.animals;

public class Lion {
	String colour = "Yellow";
	int Weight = 130;
	int age = 15;
	public void vegetarian()
	{
System.out.println(" LION WILL EAT BOTH VEGETARIAN AND NON VEGETARIAN");
	}
	public void canClimb() {
		System.out.println("CLIMBING IS NOT A HABIT OF LION");
	}
	public void getSound()
	{
		System.out.println("LION CAN SOUND LOUDLY");
	}
	public void displayLion(){
		System.out.println("Color is"+colour);
		System.out.println("Weight is"+Weight);
		System.out.println("age is"+age);
	}

}


