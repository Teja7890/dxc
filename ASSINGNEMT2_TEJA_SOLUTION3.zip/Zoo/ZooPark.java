package Zoo;

import org.animals.Elephant;
import org.animals.Lion;
import org.animals.Monkey;

public class ZooPark {
	public static void main(String[] args) {
		Lion lion = new Lion();
		lion.vegetarian();
		lion.canClimb();
		lion.getSound();
		lion.displayLion();
		Monkey monkey = new Monkey();
		monkey.vegetarian();
		monkey.canClimb();
		monkey.getSound();
		monkey.displayMonkey();
		Elephant el = new Elephant();
		el.vegetarian();
		el.canClimb();
		el.getSound();
		el.displayLElephant();
	}

}
